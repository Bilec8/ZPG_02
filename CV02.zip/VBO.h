#pragma once

#include <GL/glew.h>

class VBO {
	public:
		GLuint ID;
		VBO(GLfloat* points, GLsizeiptr size);

		void Bind();
		void Unbind();
		void Delete();
};